# Built on Folktables and the codebase https://github.com/jpgard/subgroup-robustness-grows-on-trees
__version__ = "0.0.1"
__author__ = 'Jiashuo Liu, Tianyu Wang, Peng Cui, Hongseok Namkoong'
__credits__ = 'Peng Cui\'s Group and Hongseok Namkoong\' Group'


from .fetch_method import fetch_method